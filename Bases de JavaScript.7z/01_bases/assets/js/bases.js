// Les variables en js : 

// On déclare une variable 

var Prenom;

// et on lui affecte une valeur il n'est pas nécessaire de rappeler le mot clef var pour affecter la valeur.
// Les instructions se finissent toujours par un point virgule

// var Prenom = "Salma";
Prenom = "Thomas"; 

// Il est possible d'écrire plusieurs instruction sur une même ligne

// Il est possible d'afficher une boite de dialogue de 2 manières :

// alert("Super on est bientôt vendredi !");
// window.alert("On est jeudi !");

// Affichage dans la console de la valeur de la variable Prenom
console.log(Prenom);

// Affichage d'une phrase dans la page web
document.write("C'est jeudi ! ");

// Demander à l'utilisateur une valeur 2 façons

// window.prompt("Question : on est quel jour ?", "jour de la semaine");
// prompt("Question : on est quel jour ?", "jour de la semaine");

// var jour = prompt("Question : on est quel jour ?", "jour de la semaine");

// console.log(jour);

// Attention !!!! le JS est sensible à la casse ('case sensitive')
// mavariable / maVariable / ma_variable
//             camel case     snake case
// Une variable ne peut pas commencer par un chiffre, il ne peux y avoir que des caractères alphanumérique, on ne peux pas utiliser des mots réservé pour des variables

// une variable peut être déclaré de façon explicite

var fruit;
fruit = "fraise";

// Les types de variables

// chaine de caractères (string)
var vacances = "2017";
var destination = "Malaisie";
console.log(vacances);
console.log(typeof vacances);

// Un nombre entier (integer ou int)
// var annee = 2017;
let annee = 2017;
// console.log(annee);

// Un nombre décimal (float)
var nombre_a_virgule = -5.32;

// booléen (boolean = VRAI/FAUX TRUE/FALSE)
var unBooleen = false;

// Par convention les constantes sont en majuscules
const NAISSANCE = 1980;

// la concatenation

let chiffre = 2017;
let futur = 3;
let resultat = chiffre + futur;
// console.log(resultat);
document.write(resultat);

let debutPhrase ="Aujourd'hui";
let nbStagiaires = 12;
let suitePhrase =" stagiaires";
let finPhrase =" sont présents";

let solution = debutPhrase + nbStagiaires + suitePhrase + finPhrase
console.log(solution)




