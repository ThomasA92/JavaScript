// alert("hello")

// --1 Addition

var nb1, nb2, resultat, 
// on peut déclarer plusieurs valeurs à la suite

nb1 = 10;
nb2 = 5;

// Addition de nb1 + nb2 avec l'opérateur '+'

resultat = nb1 + nb2;
console.log(resultat);

// Soustraction
// Soustraction de nb1-nb2 avec l'opérateur '-'
resultat = nb1 - nb2;
console.log(resultat);

//Multiplication
resultat = nb1 * nb2;
console.log(resultat);

// Division avec l'opérateur '/'
resultat = nb1/nb2;
console.log(resultat);

//Modulo retourne le reste d'une division avec l'opérateur '%'
resultat = nb1%nb2
console.log(resultat);


console.log("le reste de la division de " + nb1 + " par " + nb2 + " est égal à : " + resultat);

// Les écritures simplifiées

nb1 = 15;
nb1 = nb1 + 5;
console.log(nb1);

