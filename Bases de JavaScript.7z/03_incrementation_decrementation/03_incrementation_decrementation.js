// alert("Hello");

// Incrémentation 

var nb1 = 1;
nb1 = nb1 + 1 ; // j'augmente nb1 de 1
// affichage => nb1=2
console.log(nb1);

// Ecriture simplifiée, on incrémente c'est à dire qu'on ajoute 1
// nb1++ => nb1+1

nb1 ++;
console.log(nb1);

// décrémentation 
nb1 = nb1 -1;
console.log(nb1);

// Ecriture simplifiée
nb1 --;
console.log(nb1);