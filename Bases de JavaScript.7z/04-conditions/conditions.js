// alert("Hello")

// structure de base IF

// par défaut la condition à vérifier.le IF vérifie si elle est vrai
// if (true) {
//     // code qui s'execute si la valeur est vrai
// }

// var nb1 = 60;
// if (nb1 > 50) {
//     console.log("nb1 est bien inférieur à 50");
// }else{
//     console.log("nb1 est bien supérieur à 50")
// }

// Exercice
// On utilise le if pour vérifier l'age de l'internaute.
// Si il est majeur je lui souhaite la bienvenue.Si il est mineur je lui signale  que son accès refusé et je le renvoie vers un autre site. (document.location.href = https://www.google.fr/)
// Vous devrez utiliser la fonction prompt pour demander à l'internaute son âge et vous le stockez ensuite dans une variable et c'est cette variable que vous mettez dans la condition.

let age = 10

prompt("Question: Quel âge avez vous ?")
if (age > 18){
    console.log("Bienvenue")
}else{
    (document.location.href ="https://www.google.fr/")
    console.log("wesh c'est pas pour toi ici")
}