// alert("Coucou");

let nb1 = 123; // type number/int
let nb2 = "123"; // type string- chaine de caractères

console.log(nb1 == nb2); // retourne valeur de type boolean (true or false)
// doublé égale( == ) => Il vérifie que les deux valeurs sont identiques sans tenir compte du type 

console.log (nb1 === nb2); // le triple égale vérifie l'égalité STRICTE tant au niveau des valeurs que du type.


console.log (nb1 != nb2); // L'opérateur != signifie qu'il s'agit qu'il est différent

console.log (nb1 !== nb2); // l'opérateur !== signifie strictement différent tant en valeur qu'en type 