// On peut utiliser des double guillemets ou simple guillemet pour encapsuler une chaine de caractère.Dans le cas d'utilisation de simple guillemet il va falloir alors échapper les éventuelles apostrophes avec un antislash \

// alert("coucou"); exemple avec double quote
// alert(' test d\'apostrophe'); exemple avec simple quote

// L'opérateur ET : && ou AND

// Si je cumule 2 conditions :

// prenom === prenomLogin
// monAge === ageLogin
// On vérifie que l'ensemble des valeurs correspondent pour accorder l'accès au site

let prenom = "Thomas";
let monAge = 28;

let prenomLogin = prompt("saisir votre prenom");
// La fonction parseInt permet de convertir le nombre saisie par l'internaute en type number. car ce qui est récupéré par la fonction prompt sera de type chaine de caractère.
let ageLogin = parseInt(prompt("saisissez votre âge"));

if ( prenom===prenomLogin && monAge===ageLogin) {
        console.log("Bienvenue");
}else{
    console.log("Il y a une erreur de login");
}

// L'opérateur || veut dire OU (OR) (touches: ctrl alt G R 6)
// L'opérateur OU permet de vérifier si l'une ou l'autre des comparaison est vrai.Si au moins l'une d'entre elle est vrai, alors on entre dans la condition.Sinon, je rentre dans le else et dans ce cas cela voudra dire qu'aucune des 2 comparaisons n'est vrai.

if(prenom ====prenomLogin || monAge ===ageLogin){
    console.log("Bienvenue");
}else{
    console.log("Il y a une erreur sur les 2 éléments demandés");
}

// L'opérateur "!" signifie: "différent de " (not)

// valeur boolean : true or false

let utilisateurLog = true;

if(!utilisateurLog){
// si l'utilisateur n'est pas loggé
}
// ce qui revient à écrire: 
if(utilisateurLog == false){
 // si l'utilisateur n'est pas loggé
}