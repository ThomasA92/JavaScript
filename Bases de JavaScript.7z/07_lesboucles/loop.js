// alert("Salut")

// Il existe plusieurs type de boucles.Notamment la boucle FOR et la boucle WHILE que nous allons voir.

// la boucle FOR

// for (3 arguments){
//     code écrit ici
// }

// - 1 argument initialise un compteur.C'est à dire à partir de combien je commence à compter.Par défaut,le compteur est la variable 'i'
// - Le 2ème argument, la condition à vérifier qui doit donc être VRAIE(TRUE)
// - le 3ème argument est l'incrémentation, à savoir combien d'unité j'ajoute à chaque tour.En généralk on ajoute 1 ce qui correspond à i++ (si valeur supérieure on utilise i+=x)


// for(let i = 1 ; i <= 10 ; i++){
//     document.write("<p>Instruction exécutée: " + i + "</p>");
// }

// //  La boucle while (tant que)
// // Très utilisée quand on ne connait pas le nombre de tours de boucle à l'avance.

// let j = 1;
// while(j<=10){
//     document.write("<p>Instruction exécutée avec le while: " + j + "</p>");
//     j+=2;
// }

/**** 
 * J'ai 1000€ sur mon compte.
 * A chaque mois j'rajoute 50€
 * Combien de temps me faut-il pour avoir 2000€ sur mon compte 
*/
let monCompte = 1000;
let temps = 0;

// while (monCompte < 2000){
//     monCompte +=50;
//     // document.write("<p> Instruction exécutée avec le while :"+ monCompte +"</p>");
//     temps++;
//     document.write("<p> Instruction exécutée avec le while :"+ temps +"</p>");
// }




for (let monCompte = 1000; monCompte < 2000 ; monCompte += 50){
    document.write("<p>Instruction exécutée: " +  monCompte + "</p>");
    temps++;
}
document.write("cela fait "+ temps +" mois")


