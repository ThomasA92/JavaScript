/* 
Avec JavaScript
*/
// on récupère toutes les images thumbnails
/*
let myThumbnails = document.querySelectorAll('.thumbnail img');
console.log(myThumbnails)

// On a récupéré une collection (un tableau array) contenant tout nos éléments, pour leur appliquer un évènement à chacune boucle.
for(let i = 0;i < myThumbnails.length;i++) {
    myThumbnails[i].addEventListener('click',function (){
        // console.log(this.alt);
        // console.log(this.getAttribute('data-full')); 
        this.classList.add("animate__bounceIn");
        this.classList.add("animate__zoomIn");

        let valeurAlt = this.getAttribute('alt');// on récupère l'attribut alt
        let valeurDataFull = this.getAttribute('data-full'); // On récupère la valeur de l'attribut data-full

        // On envoie la valeur de valeurDataFull dans le src de la grande image (id = full)
        // document.getElementById('full').src =valeurDataFull;
        document.getElementById('full').setAttribute('src',valeurDataFull);

        // On change le contenu texte du div id="legende" pour placer le contenu du lat de l'image cliquée.
        document.getElementById('legende').textContent = valeurAlt;

        this.addEventListener('mouseout',function(){
            this.classList.add("animate__bounceIn");
            this.classList.add("animate__zoomIn");
        })
});

}

window.addEventListener('scroll', function(e){
    // window.scrollY nous permet d'avoir la distance entre le haut et le scroll effectué
    console.log(window.scrollY)

    if(window.scrollY >100){
        document.getElementById('back-to-top').style.display = 'block';
    }else {
        document.getElementById('back-to-top').style.display = 'none';
    }
});
*/


/*
------------------------AVEC JQUERY
*/

$(document).ready(function() {
    // Equivalent 
    $('.thumbnail img').on('click', function(){
        $('#full').attr('src', $(this).attr('data-full')); 
        $('legende').text($(this).attr('alt'));
        $('legende').addClass('animate__bounceIn animate__zoomIn');
        $(this).on('mouseout',function(){
            $(this).removeClass('animate__zoomIn animate__bounceIn')
        })
    });

 });


