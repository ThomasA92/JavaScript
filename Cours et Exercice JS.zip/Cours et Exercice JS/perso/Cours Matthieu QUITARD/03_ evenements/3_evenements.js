/* 
3 façon de mettre en place un évènement js :
----------------------------------------------
Anciennement:
-------------
1 - par un attribut html d'évènement exemple : onclick"
<div onclick="alert('Hello')"> Cliquez sur ce div pour voir une alerte </div>
2 -Par l'évènement directement en js
document.getElementById('unId').onclick = function () {
    // CODE ...
}

3 - La bonne pratique : on rajoute un écouteur d'évènement
doucment.getElementById('unId').addeventlistener ('click , function() {
    // CODE ;;;
}).

*/

// EVENEMENT CLICK
document.getElementById('div1').addEventListener('click', function(){
    // console.log('ok');
    // Dans un évènement, le mot clé this représente l'élément ayant reçu l'évènement.
    console.log(this.style.backgroundColor);

    let couleurActuelle = this.style.backgroundColor;

    if(couleurActuelle == 'cornflowerblue' ){
        this.style.backgroundColor = 'red';
        this.style.width = '200px';
    }else  if (couleurActuelle == 'red'){
        this.style.backgroundColor = 'orange';
        this.style.height = '200px';
        this.style.borderRadius = '50%';
    }else if (couleurActuelle == 'orange'){
        this.style.backgroundColor = 'purple';
        this.style.width = '100px';
    }else {
        this.style.backgroundColor = 'cornflowerblue';
        this.style.height = '100px';
    }

}); // fin de cet évènement click
    

// EVENEMENT DBCLICK
document.getElementById('div2').addEventListener('dblclick', function(){
    let posTop = this.style.top;
    console.log(posTop);
    let posLeft = this.style.left;
    console.log(posLeft);
     

    if(posTop == '0px' && posLeft =='0px') {
        this.style.left = '100px'
    }else if (posTop == '0px' && posLeft =='100px'){    this.style.top = '100px'
    } else if (posTop == '100px' && posLeft =='100px'){    this.style.left = '0px'
    }else {
        this.style.top= '0';
    }
        
});

// EVENEMENT MOUSEENTER & MOUSELEAVE
document.getElementById('blocImage1').addEventListener('mouseenter', function (){
    // console.log(1) =>la console est là juste pour vérifier que ça fonctionne.
    let listeImage = document.querySelectorAll('#blocImage1 img');
    console.log(listeImage)

    listeImage[0].style.top='-360px';
    listeImage[1].style.top='-360px';
});

// EXERCICE : Remettre les images dans leur position initiale lorsque l'on sort du survol avec la souris(mouseleave)

document.getElementById('blocImage1').addEventListener('mouseleave', function (){
    // console.log(1) =>la console est là juste pour vérifier que ça fonctionne.
    let listeImage = document.querySelectorAll('#blocImage1 img');
    console.log(listeImage)

    listeImage[0].style.top=' 0px';
    listeImage[1].style.top=' 0px';
});

// CAROUSEL

document.getElementById('changerImage').addEventListener('click', function(e){
    // le fait de mettre un argument de réception dans la fonction qui se déclenche, permet de récupérer cette évènement.
    // Cela nous permet ensuite,notamment, de le bloquer :
    e.preventDefault(); // . preventDefault() permet d'annuler un évènement.

    let imageEnCours = document.getElementById('blocImage2').getAttribute('date-image');
    console.log(imageEnCours)

    if(imageEnCours == 'image1'){
        document.getElementById('image1').style.opacity=0;
        document.getElementById('image2').style.opacity=1;
        document.getElementById('blocImage2').setAttribute('data-image', 'image2');
    }else if (imageEnCours =='image2'){
        document.getElementById('image1').style.opacity=0;
        document.getElementById('image2').style.opacity=1;
        document.getElementById('blocImage2').setAttribute('data-image', 'image3');
    }else if (imageEnCours =='image3'){
        document.getElementById('image1').style.opacity=0;
        document.getElementById('image2').style.opacity=1;
        document.getElementById('blocImage2').setAttribute('data-image', 'image4');
    }else if (imageEnCours =='image2'){
        document.getElementById('image1').style.opacity=0;
        document.getElementById('image2').style.opacity=1;
        document.getElementById('blocImage2').setAttribute('data-image', 'image5');
    }else{
        document.getElementById('image1').style.opacity=0;
        document.getElementById('image2').style.opacity=1;
        document.getElementById('blocImage2').setAttribute('data-image', 'image1');
    }
});

// pour déclencher une fonction selon un timer
// setInterval(la_fonction, timer_milliseconds)
// L'idée est de déclencher le CAROUSEL avec 

function activeCarousel(e = '') {
    // le fait de mettre un argument de réception dans la fonction qui se déclenche, permet de récupérer cet évènement.
    // Cela nous permet ensuite notamment de le bloquer :
    if (e != '') {
        e.preventDefault();
    }   
    let imageEnCours = document.getElementById('blocImage2').getAttribute('data-image');
    console.log(imageEnCours);

    if(imageEnCours == 'image1') {
        document.getElementById('image1').style.opacity = 0;
        document.getElementById('image2').style.opacity = 1;
        document.getElementById('blocImage2').setAttribute('data-image', 'image2');
    } else if(imageEnCours == 'image2') {
        document.getElementById('image2').style.opacity = 0;
        document.getElementById('image3').style.opacity = 1;
        document.getElementById('blocImage2').setAttribute('data-image', 'image3');
    } else if(imageEnCours == 'image3') {
        document.getElementById('image3').style.opacity = 0;
        document.getElementById('image4').style.opacity = 1;
        document.getElementById('blocImage2').setAttribute('data-image', 'image4');
    } else if(imageEnCours == 'image4') {
        document.getElementById('image4').style.opacity = 0;
        document.getElementById('image5').style.opacity = 1;
        document.getElementById('blocImage2').setAttribute('data-image', 'image5');
    } else {
        document.getElementById('image5').style.opacity = 0;
        document.getElementById('image1').style.opacity = 1;
        document.getElementById('blocImage2').setAttribute('data-image', 'image1');
        // clearInterval(animationCarousel); // pour arreter le setInterval()
    }    
}


// EXERCICE :
// Faire un nouveau div dans la page HTML avec une couleur de fond
// Tant que l'utilisateur garde le clic appuyé sur la souris, on change la couleur du div.
// Lorsque l'utilisateur relache le clic de la souris, on remet la couleur initiale.
// Evement => clic appuyé :mosuedown
// evenement => clic relaché : mouseup

// mousedown
document.getElementById('div3').addEventListener('mousedown', function () {
    this.style.backgroundColor = "red";
});

// mouseup
document.getElementById('div3').addEventListener('mouseup', function () {
    this.style.backgroundColor = "darkgreen";
});

// changer la couleur au survol
// var color = 100000;

// function changerCouleur(elem) {
//     if(color >=  999999) {
//         color = 100000;
//     }
//     color += 2154;
//     console.log(color);
//     return elem.style.backgroundColor = '#' + color ;
// }
// var effet;
// document.getElementById('div3').addEventListener('mouseenter', function () {
//     effet = setInterval(function () {
//         changerCouleur(document.getElementById('div3'));
//     }, 1000);
// });

// document.getElementById('div3').addEventListener('mouseleave', function () {
//     clearInterval(effet);
// });