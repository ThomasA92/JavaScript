$(document).ready(function(){
    // Il faut bloquer le rechargement de page lors du clic sur les liens a car ils nous servent de lanceur pour les évènements.

    // En natif
    let listeA = document.getElementsByTagName('a');
    for(let i = 0; i <listeA.length;i++){
        listeA[i].addEventListener('click',function(e){
            e.preventDefault();
        
        });
    }

    // avec jQuery
    // .on() est l'équivalent du .addEventListener() en natif.
    $('a').on('click',function(e){
        e.preventDefault();
    })

    // LES ANIMATIONS FADE
    // --------------------
    // Permet de faire apparaître ou disparaître un élément.

    // $('#disparition.on('click,function(){}); => Autre façon de l'écrire
    // Disparition : fadeOut(temps_danimation) => Autre façon de l'écrire
    $('#disparition').click(function() {
        $('#div1').fadeOut();
    });

    // Exercice : faire la même chose pour le div suivant bouton : #apparition, div : div2
    // Apparition :fadeIn(temps_danimation)

    $('#apparition').click(function(){
        $('#div2').fadeIn(3000);
    });

    // Toggle: soit l'un, soit l'autre.
    $('#toggle').on('click',function(){
        $('#div3').fadeToggle(2000);

        let textContent = $(this).text(); // => ici on récupère le contenu texte
        if(textContent == 'Disparition'){ // Selon la valeur du texte récupéré, on change le texte du bouton.
            $(this).text('Apparition');
        } else {
            $(this).text('Disparition');
        }
    })
    
});

// fadeTo(temps, valeyur_opacity)
// fadeTo permet de gérer la valeur finale de l'opacité
$('#fadeTo').on('click', function(){
    $('#div4').fadeTo(2000,0.2);
});

// LES ANIMATIONS AVEC ANIMATE
// ---------------------------
// .animate({les_proprietes_css}, temps)
// .delay(temps) // permet de mettre une pause dans l'animation.

$('#simple').on('click',function(){

    $('#div5').animate ({ left: '400px',width:'1000px', height: '100px', borderRadius:'50%'},2000)
    .delay(2000)
    .animate({ left:'0', width :'200px', height:'200px'},2000);
});